package br.com.fomezero.joaofood.activities

class RecommendationResponse {

}
