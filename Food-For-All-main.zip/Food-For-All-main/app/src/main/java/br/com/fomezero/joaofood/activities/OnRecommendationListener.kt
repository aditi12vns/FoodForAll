package br.com.fomezero.joaofood.activities

open class OnRecommendationListener {
    //todo

}
