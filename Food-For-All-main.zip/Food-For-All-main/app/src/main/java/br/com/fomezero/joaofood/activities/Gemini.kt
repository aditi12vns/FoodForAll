package br.com.fomezero.joaofood.activities

class Gemini {
//todo
    companion object {
    fun <Application> initialize(application: Application, s: String) {
//todo
    }

    fun recommend(userId: String, contextData: String, onRecommendationListener: OnRecommendationListener) {
//todo
    }
}
}
